
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// functions/config.js
var config = {
  API_TOKEN: process.env.API_TOKEN || "OSDZ07/5WEx1h-4ZEc?zcdfdIBqjAhx20200O9VwATpypBcGw1vb!?=d4OIrQLYy/96!q5ozRAxu=muvjKGbtClIkm6YpKxPDm21L8GZjGs6Cuek883SzMj6Gbf3!wZ1Bw8SzBuIalEFAKajfIPIjU2fIc5re73rag-4V7lnGHQ7VKpn0JtCUptEsdo?ng/16=kWN47PwBcnZtPl6p5uDNI/BpJOGlx5g-soX?DnZa?Yi!lrcuEXOf/y4Gk=yf7H"
};
var config_default = config;
export {
  config_default as default
};
