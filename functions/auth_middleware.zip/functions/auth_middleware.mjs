
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// functions/config.js
var config = {
  API_TOKEN: process.env.API_TOKEN || "OSDZ07/5WEx1h-4ZEc?zcdfdIBqjAhx20200O9VwATpypBcGw1vb!?=d4OIrQLYy/96!q5ozRAxu=muvjKGbtClIkm6YpKxPDm21L8GZjGs6Cuek883SzMj6Gbf3!wZ1Bw8SzBuIalEFAKajfIPIjU2fIc5re73rag-4V7lnGHQ7VKpn0JtCUptEsdo?ng/16=kWN47PwBcnZtPl6p5uDNI/BpJOGlx5g-soX?DnZa?Yi!lrcuEXOf/y4Gk=yf7H"
};
var config_default = config;

// functions/auth_middleware.js
var authenticateToken = (req, res, next) => {
  try {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (!token) {
      return res.status(401).json({ error: "Token no proporcionado" });
    }
    if (token !== config_default.API_TOKEN) {
      return res.status(403).json({ error: "Token inv\xE1lido" });
    }
    next();
  } catch (error) {
    console.error("Error en autenticaci\xF3n:", error);
    res.status(500).json({ error: "Error interno del servidor" });
  }
};
var auth_middleware_default = authenticateToken;
export {
  auth_middleware_default as default
};
