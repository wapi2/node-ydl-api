var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var server_exports = {};
__export(server_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_serverless_http = __toESM(require("serverless-http"), 1);
var import_ytdl_core = __toESM(require("ytdl-core"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_auth_middleware = __toESM(require("./auth_middleware.js"), 1);
const app = (0, import_express.default)();
const router = import_express.default.Router();
app.use((0, import_cors.default)());
router.get("/", (req, res) => {
  const ping = /* @__PURE__ */ new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping at: ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  res.sendStatus(200);
});
const protectedRouter = import_express.default.Router();
protectedRouter.get("/info", async (req, res) => {
  const { url } = req.query;
  if (!url) {
    return res.status(400).send("Invalid query");
  }
  const isValid = import_ytdl_core.default.validateURL(url);
  if (!isValid) {
    return res.status(400).send("Invalid url");
  }
  const info = (await import_ytdl_core.default.getInfo(url)).videoDetails;
  const title = info.title;
  const thumbnail = info.thumbnails[2].url;
  res.send({ title, thumbnail });
});
protectedRouter.get("/mp3", async (req, res) => {
  const { url } = req.query;
  if (!url) {
    return res.status(400).send("Invalid query");
  }
  const isValid = import_ytdl_core.default.validateURL(url);
  if (!isValid) {
    return res.status(400).send("Invalid url");
  }
  const videoName = (await import_ytdl_core.default.getInfo(url)).videoDetails.title;
  res.header("Content-Disposition", `attachment; filename="${videoName}.mp3"`);
  res.header("Content-type", "audio/mpeg3");
  (0, import_ytdl_core.default)(url, { quality: "highestaudio", format: "mp3" }).pipe(res);
});
protectedRouter.get("/mp4", async (req, res) => {
  const { url } = req.query;
  if (!url) {
    return res.status(400).send("Invalid query");
  }
  const isValid = import_ytdl_core.default.validateURL(url);
  if (!isValid) {
    return res.status(400).send("Invalid url");
  }
  const videoName = (await import_ytdl_core.default.getInfo(url)).videoDetails.title;
  res.header("Content-Disposition", `attachment; filename="${videoName}.mp4"`);
  (0, import_ytdl_core.default)(url, {
    quality: "highest",
    format: "mp4"
  }).pipe(res);
});
router.use(["/info", "/mp3", "/mp4"], import_auth_middleware.default, protectedRouter);
app.use("/.netlify/functions/server", router);
const handler = (0, import_serverless_http.default)(app);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
